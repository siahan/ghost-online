@echo off
cd /d "%~dp0"
start "" pythonw "%~dp0money_patcher.pyw"
