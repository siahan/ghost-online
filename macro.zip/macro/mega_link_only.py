import io
import tempfile
import os
from mega import Mega

def download_mega_file_by_link_only(file_link, chunk_size=1024*1024):
    """
    MEGA 링크만으로 파일을 메모리로 다운로드하는 함수 (계정 정보 불필요)
    
    Args:
        file_link (str): MEGA 파일 공유 링크
        chunk_size (int): 청크 크기 (기본값: 1MB)
    
    Returns:
        bytes: 파일 데이터 (메모리에 저장)
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 링크에서 파일 정보 가져오기
        file_info = mega.get_link_info(file_link)
        file_name = file_info['name']
        file_size = file_info['size']
        
        print(f"다운로드 중: {file_name} ({file_size} bytes)")
        
        # 파일을 메모리로 다운로드 (계정 정보 없이)
        file_data = mega.download_url(file_link)
        
        print(f"다운로드 완료: {len(file_data)} bytes")
        
        return file_data
        
    except Exception as e:
        print(f"다운로드 오류: {e}")
        return None

def download_mega_file_by_link_chunked(file_link, chunk_size=1024*1024):
    """
    MEGA 링크만으로 파일을 청크 단위로 다운로드하는 함수 (메모리 효율적)
    
    Args:
        file_link (str): MEGA 파일 공유 링크
        chunk_size (int): 청크 크기 (기본값: 1MB)
    
    Yields:
        bytes: 파일 데이터 청크
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 링크에서 파일 정보 가져오기
        file_info = mega.get_link_info(file_link)
        file_name = file_info['name']
        file_size = file_info['size']
        
        print(f"다운로드 시작: {file_name} ({file_size} bytes)")
        
        # 임시 파일로 다운로드 후 청크 단위로 읽기
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_path = temp_file.name
        
        try:
            # 파일 다운로드 (계정 정보 없이)
            mega.download_url(file_link, dest_path=temp_path)
            
            # 청크 단위로 읽기
            with open(temp_path, 'rb') as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk
                    
        finally:
            # 임시 파일 삭제
            if os.path.exists(temp_path):
                os.unlink(temp_path)
                
    except Exception as e:
        print(f"다운로드 오류: {e}")
        yield None

def download_mega_file_by_link_with_progress(file_link, progress_callback=None):
    """
    진행률 표시가 있는 MEGA 링크 다운로드
    
    Args:
        file_link (str): MEGA 파일 공유 링크
        progress_callback (function): 진행률 콜백 함수 (percent: float)
    
    Returns:
        bytes: 파일 데이터
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 링크에서 파일 정보 가져오기
        file_info = mega.get_link_info(file_link)
        file_name = file_info['name']
        file_size = file_info['size']
        
        print(f"다운로드 시작: {file_name} ({file_size} bytes)")
        
        # 파일 다운로드 (계정 정보 없이)
        file_data = mega.download_url(file_link)
        
        # 진행률 100% 알림
        if progress_callback:
            progress_callback(100.0)
        
        print(f"다운로드 완료: {len(file_data)} bytes")
        
        return file_data
        
    except Exception as e:
        print(f"다운로드 오류: {e}")
        return None

def get_mega_file_info(file_link):
    """
    MEGA 링크에서 파일 정보만 가져오는 함수
    
    Args:
        file_link (str): MEGA 파일 공유 링크
    
    Returns:
        dict: 파일 정보 (이름, 크기, 타입 등)
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 링크에서 파일 정보 가져오기
        file_info = mega.get_link_info(file_link)
        
        return {
            'name': file_info['name'],
            'size': file_info['size'],
            'type': 'file' if file_info['size'] > 0 else 'folder'
        }
        
    except Exception as e:
        print(f"파일 정보 가져오기 오류: {e}")
        return None

# 사용 예시
if __name__ == "__main__":
    # MEGA 파일 링크
    FILE_LINK = "https://mega.nz/file/..."
    
    # 방법 1: 링크만으로 전체 파일 다운로드
    print("=== 링크만으로 전체 파일 다운로드 ===")
    file_data = download_mega_file_by_link_only(FILE_LINK)
    
    if file_data:
        # 메모리에서 파일 처리
        with io.BytesIO(file_data) as f:
            content = f.read().decode('utf-8')
            print(f"파일 내용: {content[:100]}...")  # 처음 100자만 출력
    
    # 방법 2: 링크만으로 청크 단위 다운로드
    print("\n=== 링크만으로 청크 단위 다운로드 ===")
    total_size = 0
    for chunk in download_mega_file_by_link_chunked(FILE_LINK):
        if chunk is None:
            break
        total_size += len(chunk)
        print(f"청크 다운로드: {len(chunk)} bytes (총 {total_size} bytes)")
    
    # 방법 3: 진행률 표시 다운로드
    print("\n=== 진행률 표시 다운로드 ===")
    def progress_callback(percent):
        print(f"진행률: {percent:.1f}%")
    
    file_data = download_mega_file_by_link_with_progress(FILE_LINK, progress_callback)
    
    if file_data:
        print(f"최종 파일 크기: {len(file_data)} bytes")
    
    # 방법 4: 파일 정보만 가져오기
    print("\n=== 파일 정보 가져오기 ===")
    file_info = get_mega_file_info(FILE_LINK)
    if file_info:
        print(f"파일명: {file_info['name']}")
        print(f"크기: {file_info['size']} bytes")
        print(f"타입: {file_info['type']}") 