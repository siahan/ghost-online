import configparser
import os

def add_mega_config():
    """
    settings.ini 파일에 MEGA 설정을 추가하는 함수
    """
    # configparser 객체 생성
    config = configparser.ConfigParser()
    
    # settings.ini 파일 경로
    script_dir = os.path.dirname(os.path.abspath(__file__))
    settings_file = os.path.join(script_dir, 'settings.ini')
    
    # 기존 설정 읽기
    if os.path.exists(settings_file):
        config.read(settings_file, encoding='utf-8')
    
    # MEGA 설정 추가
    if 'MEGA' not in config:
        config['MEGA'] = {}
    
    config['MEGA']['Email'] = 'your_mega_email@example.com'
    config['MEGA']['Password'] = 'your_mega_password'
    config['MEGA']['DefaultFolder'] = 'your_default_folder_name'
    
    # 설정 저장
    with open(settings_file, 'w', encoding='utf-8') as configfile:
        config.write(configfile)
    
    print("MEGA 설정이 추가되었습니다.")

def get_mega_config():
    """
    settings.ini에서 MEGA 설정을 읽어오는 함수
    
    Returns:
        dict: MEGA 설정 정보
    """
    config = configparser.ConfigParser()
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    settings_file = os.path.join(script_dir, 'settings.ini')
    
    if not os.path.exists(settings_file):
        return None
    
    config.read(settings_file, encoding='utf-8')
    
    if 'MEGA' not in config:
        return None
    
    return {
        'email': config['MEGA'].get('Email', ''),
        'password': config['MEGA'].get('Password', ''),
        'default_folder': config['MEGA'].get('DefaultFolder', '')
    }

# 사용 예시
if __name__ == "__main__":
    # MEGA 설정 추가
    add_mega_config()
    
    # MEGA 설정 읽기
    mega_config = get_mega_config()
    if mega_config:
        print("MEGA 설정:")
        print(f"이메일: {mega_config['email']}")
        print(f"기본 폴더: {mega_config['default_folder']}")
    else:
        print("MEGA 설정을 찾을 수 없습니다.") 