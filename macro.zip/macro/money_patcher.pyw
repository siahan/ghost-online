import tkinter as tk
from tkinter import messagebox, ttk
import requests
import os
import subprocess
import threading
import urllib.parse
import json
import sys
import tempfile
import io
import time
import shutil
import configparser
import re
from typing import List, Optional, Tuple

# 봇설정용 bot.json — 구글 드라이브 공유 링크 전체, 또는 uc?id=… 링크, 또는 파일 ID만
# (예: https://drive.google.com/file/d/파일ID/view?usp=sharing)
BOT_JSON_GOOGLE_DRIVE_URL_OR_ID = (
    "https://drive.google.com/file/d/17sw9aX9zkrE9STxYljIJB-80JM1Dogdf/view?usp=drive_link"
)

class MoneyPatcher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("귀혼 패치기")
        self.root.geometry("150x130")
        self.root.resizable(False, False)
        
        # 캡션 제거
        self.root.overrideredirect(True)
        
        # 항상 최상단에 유지
        self.root.attributes('-topmost', True)
        
        # 화면 중앙 최상단에 위치
        self.root.update_idletasks()
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - 150) // 2
        y = 0  # 최상단
        self.root.geometry(f"150x130+{x}+{y}")
        
        # 설정 파일 경로
        self.config_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "autostart_config.json")
        
        # 자동 실행 설정 확인 및 생성
        self.autostart_enabled = self.check_autostart_config()
        
        # 중앙 정렬을 위한 메인 프레임 (상단 여백 추가 - 타이틀 바 고려)
        main_frame = tk.Frame(self.root)
        main_frame.pack(expand=True, fill='both', padx=1, pady=(25, 1))
        
        # 버튼들을 담을 프레임 (한 줄로 배치)
        button_frame = tk.Frame(main_frame)
        button_frame.pack(expand=True)
        
        # 이미지 버튼
        self.image_btn = tk.Button(
            button_frame, 
            text="다운로드", 
            font=("Arial", 7, "bold"),
            width=7,
            height=2,
            bg="#4CAF50",
            fg="white",
            command=self.download_images
        )
        self.image_btn.pack(side='left', padx=2)
        
        # 매크로 버튼
        self.macro_btn = tk.Button(
            button_frame, 
            text="매크로", 
            font=("Arial", 7, "bold"),
            width=7,
            height=2,
            bg="#2196F3",
            fg="white",
            command=self.run_macro_bat
        )
        self.macro_btn.pack(side='left', padx=2)
        
        # 봇설정과 종료 버튼을 담을 프레임
        control_frame = tk.Frame(main_frame)
        control_frame.pack(pady=(1, 0))
        
        # 봇설정 버튼
        self.bot_config_btn = tk.Button(
            control_frame, 
            text="봇설정", 
            font=("Arial", 6, "bold"),
            width=5,
            height=1,
            bg="#9C27B0",
            fg="white",
            command=self.open_bot_config
        )
        self.bot_config_btn.pack(side='left', padx=2)
        
        # 종료 버튼
        self.exit_btn = tk.Button(
            control_frame, 
            text="종료", 
            font=("Arial", 6, "bold"),
            width=5,
            height=1,
            bg="#F44336",
            fg="white",
            command=self.root.quit
        )
        self.exit_btn.pack(side='left', padx=2)
        
        # 자동 실행 체크박스를 담을 프레임
        autostart_frame = tk.Frame(main_frame)
        autostart_frame.pack(pady=(1, 0))
        
        # 자동 실행 체크박스
        self.autostart_var = tk.BooleanVar(value=self.autostart_enabled)
        self.autostart_checkbox = tk.Checkbutton(
            autostart_frame, 
            text="자동실행", 
            font=("Arial", 6, "bold"),
            variable=self.autostart_var,
            command=self.toggle_autostart
        )
        self.autostart_checkbox.pack()
        
        # 상태 표시 레이블
        self.status_label = tk.Label(main_frame, text="", font=("Arial", 6))
        self.status_label.pack(pady=(0, 0))
        
        # 최신 버전을 위한 GitHub 저장소 (macro.zip — Branches API로 SHA 붙여 최신 커밋 기준 다운로드)
        self.github_owner = "siahan"
        self.github_repo = "ghost-online"
        self.github_branch = "main"
        self.base_urls = [
            "https://github.com/siahan/ghost-online/raw/main",
            "https://raw.githubusercontent.com/siahan/ghost-online/main",
        ]
        self.macro_filename = "macro.zip"
        
        # bot.json / settings.ini 경로
        self.bot_json_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot.json")
        self.setting_ini_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.ini")
        
        pc_d, vm_d = self._read_pc_vm_from_settings()
        self.bot_config = {"pc": pc_d, "vm": vm_d}
        
        self.init_bot_json()
        
    def get_latest_file_urls(self, filename):
        """최신 파일 URL들을 생성합니다."""
        # 여러 GitHub URL 형식으로 시도
        urls = []
        for base_url in self.base_urls:
            urls.append(f"{base_url}/{filename}")
        return urls

    @staticmethod
    def _github_raw_cache_bust(url: str) -> str:
        """GitHub raw CDN 보조: main 브랜치 URL에 요청마다 다른 쿼리(cb=밀리초)."""
        cb = int(time.time() * 1000)
        return f"{url}{'&' if '?' in url else '?'}cb={cb}"

    def _try_fetch_main_commit_sha(self) -> Optional[str]:
        """GitHub API로 main 브랜치 tip 커밋 SHA. 성공 시 raw URL이 커밋별로 달라져 CDN 옛 zip 문제를 줄임."""
        api = (
            f"https://api.github.com/repos/{self.github_owner}/{self.github_repo}"
            f"/branches/{self.github_branch}"
        )
        try:
            r = requests.get(
                api,
                timeout=15,
                headers={
                    "Accept": "application/vnd.github+json",
                    "User-Agent": "MoneyPatcher/1.0",
                },
            )
            r.raise_for_status()
            sha = (r.json().get("commit") or {}).get("sha")
            if isinstance(sha, str) and len(sha) >= 7:
                return sha
        except Exception:
            pass
        return None

    def _macro_download_url_plan(self, filename: str) -> List[Tuple[str, bool]]:
        """(요청 URL, main용 캐시버스트 여부). SHA URL은 버스트 불필요."""
        plan: List[Tuple[str, bool]] = []
        sha = self._try_fetch_main_commit_sha()
        if sha:
            plan.append(
                (
                    f"https://raw.githubusercontent.com/{self.github_owner}/"
                    f"{self.github_repo}/{sha}/{filename}",
                    False,
                )
            )
            plan.append(
                (
                    f"https://github.com/{self.github_owner}/{self.github_repo}/raw/"
                    f"{sha}/{filename}",
                    False,
                )
            )
        for u in self.get_latest_file_urls(filename):
            plan.append((u, True))
        return plan

    def download_file_to_memory(self, filename):
        """파일을 메모리에 다운로드. macro 등: 최신 커밋 SHA URL 우선, 실패 시 main+cb."""
        url_plan = self._macro_download_url_plan(filename)
        last_error = None
        no_cache_headers = {"Cache-Control": "no-cache", "Pragma": "no-cache"}

        for i, (url, use_branch_bust) in enumerate(url_plan):
            try:
                self.update_status(f"다운로드 시도 {i+1}/{len(url_plan)}: {filename}")
                req_url = (
                    self._github_raw_cache_bust(url) if use_branch_bust else url
                )

                response = requests.get(
                    req_url,
                    stream=True,
                    timeout=60,
                    headers=no_cache_headers,
                )
                response.raise_for_status()
                
                # 메모리에 파일 내용 저장
                file_content = io.BytesIO()
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        file_content.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            progress = (downloaded / total_size) * 100
                            self.update_status(f"다운로드 중... {progress:.1f}%")
                
                file_content.seek(0)  # 포인터를 처음으로 되돌림
                self.update_status(f"다운로드 완료: {filename}")
                return file_content
                
            except Exception as e:
                last_error = e
                self.update_status(f"URL {i+1} 실패: {str(e)}")
                continue
        
        raise Exception(f"모든 URL에서 다운로드 실패. 마지막 오류: {str(last_error)}")
    
    def save_memory_file(self, file_content, filename):
        """메모리의 파일을 임시 파일로 저장합니다."""
        try:
            # 임시 파일 생성
            temp_dir = os.path.dirname(os.path.abspath(__file__))
            file_path = os.path.join(temp_dir, filename)
            
            with open(file_path, 'wb') as f:
                f.write(file_content.getvalue())
            
            return file_path
            
        except Exception as e:
            raise Exception(f"파일 저장 실패: {str(e)}")
    
    def check_autostart_config(self):
        """자동 실행 설정을 확인하고 생성합니다."""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    autostart_enabled = config.get('start', False)
                    if autostart_enabled:
                        self.setup_autostart()
                    return autostart_enabled
            else:
                # 설정 파일이 없으면 생성
                config = {'start': False}
                with open(self.config_file, 'w', encoding='utf-8') as f:
                    json.dump(config, f, ensure_ascii=False, indent=2)
                return False
        except Exception as e:
            print(f"설정 파일 처리 중 오류: {e}")
            return False
    
    def _get_autostart_command(self):
        """시작 프로그램(Run)에 등록할 명령 한 줄. 절대 경로·pythonw 명시(.py/.pyw)."""
        if getattr(sys, "frozen", False):
            return f'"{os.path.abspath(sys.executable)}"'
        script_path = os.path.normpath(os.path.abspath(__file__))
        ext = os.path.splitext(script_path)[1].lower()
        if ext in (".py", ".pyw"):
            py = os.path.normpath(sys.executable)
            low = py.lower()
            if low.endswith("python.exe"):
                pyw = py[:-10] + "pythonw.exe"
            elif low.endswith("pythonw.exe"):
                pyw = py
            else:
                cand = os.path.join(os.path.dirname(py), "pythonw.exe")
                pyw = cand if os.path.isfile(cand) else py
            if not os.path.isfile(pyw):
                pyw = py
            return f'"{pyw}" "{script_path}"'
        return f'"{script_path}"'

    def setup_autostart(self):
        """윈도우 시작 프로그램(HKCU ... Run)에 등록 — 부팅 후 로그온 시 실행."""
        try:
            import winreg

            cmd = self._get_autostart_command()
            key = winreg.CreateKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
            )
            try:
                try:
                    winreg.DeleteValue(key, "귀혼패치기")
                except OSError:
                    pass
                winreg.SetValueEx(key, "MoneyPatcher", 0, winreg.REG_SZ, cmd)
            finally:
                winreg.CloseKey(key)
        except Exception as e:
            print(f"자동 실행 설정 중 오류: {e}")

    def remove_autostart(self):
        """시작 프로그램 등록 제거."""
        try:
            import winreg

            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_SET_VALUE,
            )
            try:
                for name in ("MoneyPatcher", "귀혼패치기"):
                    try:
                        winreg.DeleteValue(key, name)
                    except OSError:
                        pass
            finally:
                winreg.CloseKey(key)
        except FileNotFoundError:
            pass
        except OSError as e:
            if getattr(e, "winerror", None) not in (2, 203):
                print(f"자동 실행 제거 중 오류: {e}")
    
    def _read_pc_vm_from_settings(self):
        """settings.ini에서 Pc, Vm 기본값."""
        pc, vm = "1", "1"
        if not os.path.exists(self.setting_ini_path):
            return pc, vm
        try:
            cfg = configparser.ConfigParser()
            cfg.read(self.setting_ini_path, encoding="utf-8")
            d = cfg["DEFAULT"]
            pv = d.get("Pc") or d.get("pc") or ""
            vv = d.get("Vm") or d.get("vm") or ""
            if str(pv).strip():
                pc = str(pv).strip()
            if str(vv).strip():
                vm = str(vv).strip()
        except Exception:
            pass
        return pc, vm

    def init_bot_json(self):
        """bot.json은 '봇설정' 클릭 시 구글 드라이브에서 받아 패치기 폴더에 저장."""
        pass

    @staticmethod
    def _parse_google_drive_file_id(url_or_id: str) -> str:
        s = (url_or_id or "").strip()
        if not s:
            return ""
        m = re.search(r"/file/d/([a-zA-Z0-9_-]+)", s)
        if m:
            return m.group(1)
        m = re.search(r"[?&]id=([a-zA-Z0-9_-]+)", s)
        if m:
            return m.group(1)
        if re.fullmatch(r"[a-zA-Z0-9_-]{10,}", s):
            return s
        return ""

    def _download_google_drive_to_memory(self, file_id: str) -> io.BytesIO:
        """구글 드라이브 공개 파일을 BytesIO로 받음 (작은 파일·바이러스 스캔 확인 페이지 대응)."""
        session = requests.Session()
        url = "https://drive.google.com/uc"
        params = {"export": "download", "id": file_id}
        r = session.get(url, params=params, stream=True, timeout=90)
        r.raise_for_status()
        confirm = None
        for k, v in r.cookies.items():
            if k.startswith("download_warning"):
                confirm = v
                break
        if confirm:
            r.close()
            params = {"export": "download", "id": file_id, "confirm": confirm}
            r = session.get(url, params=params, stream=True, timeout=90)
            r.raise_for_status()
        buf = io.BytesIO()
        for chunk in r.iter_content(65536):
            if chunk:
                buf.write(chunk)
        r.close()
        buf.seek(0)
        sample = buf.getvalue()[:500].lstrip()
        if sample.startswith(b"<") or sample.startswith(b"<!"):
            raise Exception(
                "드라이브에서 파일 대신 HTML을 받았습니다. "
                "링크가 '링크가 있는 모든 사용자'로 공개돼 있는지·파일 ID를 확인하세요."
            )
        buf.seek(0)
        return buf

    def open_bot_config(self):
        """구글 드라이브에서 bot.json 다운로드 후 PC/VM 설정 창 표시."""

        def worker():
            try:
                fid = self._parse_google_drive_file_id(BOT_JSON_GOOGLE_DRIVE_URL_OR_ID)
                if not fid:
                    self.root.after(
                        0,
                        lambda: messagebox.showerror(
                            "봇 설정",
                            "money_patcher.pyw 상단의 BOT_JSON_GOOGLE_DRIVE_URL_OR_ID 에\n"
                            "구글 드라이브에 올린 bot.json 공유 링크(또는 파일 ID)를 넣으세요.",
                        ),
                    )
                    return
                self.update_status("bot.json 다운로드 중...")
                buf = self._download_google_drive_to_memory(fid)
                text = buf.getvalue().decode("utf-8-sig")
                bot_data = json.loads(text)
                if not isinstance(bot_data, dict):
                    raise Exception("bot.json이 JSON 객체가 아닙니다.")
                with open(self.bot_json_path, "w", encoding="utf-8") as f:
                    json.dump(bot_data, f, ensure_ascii=False, indent=2)
                self.root.after(0, self._open_bot_config_dialog)
            except Exception as e:
                self.root.after(
                    0,
                    lambda err=str(e): messagebox.showerror(
                        "봇 설정",
                        f"bot.json 다운로드/저장 실패:\n{err}",
                    ),
                )
            finally:
                self.root.after(0, lambda: self.update_status(""))
                self.root.after(0, lambda: self.bot_config_btn.config(state="normal"))

        self.bot_config_btn.config(state="disabled")
        threading.Thread(target=worker, daemon=True).start()

    def _open_bot_config_dialog(self):
        """PC(1~14) 숫자 입력 + VM(1~4) 콤보로 settings.ini 반영 (로컬 bot.json 사용)."""
        if not os.path.isfile(self.bot_json_path):
            messagebox.showerror(
                "오류",
                f"bot.json이 없습니다.\n{self.bot_json_path}",
            )
            return

        pc_d, vm_d = self._read_pc_vm_from_settings()
        config_window = tk.Toplevel(self.root)
        config_window.title("봇 설정")
        config_window.geometry("300x120")
        config_window.resizable(False, False)
        config_window.attributes("-topmost", True)

        config_window.update_idletasks()
        sw = config_window.winfo_screenwidth()
        sh = config_window.winfo_screenheight()
        config_window.geometry(f"300x120+{(sw - 300) // 2}+{(sh - 120) // 2}")

        main_frame = tk.Frame(config_window, padx=10, pady=10)
        main_frame.pack(fill="both", expand=True)

        tk.Label(main_frame, text="PC (1~14):", font=("Arial", 9)).grid(row=0, column=0, sticky="w", pady=4)
        pc_entry = tk.Entry(main_frame, width=8, font=("Arial", 9))
        pc_entry.insert(0, pc_d)
        pc_entry.grid(row=0, column=1, sticky="w", pady=4, padx=6)

        tk.Label(main_frame, text="VM (1~4):", font=("Arial", 9)).grid(row=1, column=0, sticky="w", pady=4)
        vm_var = tk.StringVar(value=vm_d if vm_d in ("1", "2", "3", "4") else "1")
        vm_combo = ttk.Combobox(
            main_frame,
            textvariable=vm_var,
            values=("1", "2", "3", "4"),
            state="readonly",
            width=6,
        )
        vm_combo.grid(row=1, column=1, sticky="w", pady=4, padx=6)

        btn_frame = tk.Frame(main_frame)
        btn_frame.grid(row=2, column=0, columnspan=2, pady=10)

        def save_config():
            try:
                raw = pc_entry.get().strip()
                if not raw.isdigit():
                    raise Exception("PC는 1~14 숫자만 입력하세요.")
                pc_num = int(raw)
                if pc_num < 1 or pc_num > 14:
                    raise Exception("PC는 1~14 사이만 가능합니다.")
                vm_num = int(vm_var.get())
                if vm_num < 1 or vm_num > 4:
                    raise Exception("VM은 1~4만 선택하세요.")

                self.update_setting_ini_from_bot_json(pc_num, vm_num)
                self.bot_config["pc"] = str(pc_num)
                self.bot_config["vm"] = str(vm_num)
                messagebox.showinfo("저장", "settings.ini에 반영되었습니다.")
                config_window.destroy()
            except Exception as e:
                messagebox.showerror("오류", str(e))

        tk.Button(
            btn_frame,
            text="저장",
            font=("Arial", 9, "bold"),
            width=8,
            bg="#4CAF50",
            fg="white",
            command=save_config,
        ).pack(side="left", padx=6)
        tk.Button(
            btn_frame,
            text="취소",
            font=("Arial", 9, "bold"),
            width=8,
            bg="#F44336",
            fg="white",
            command=config_window.destroy,
        ).pack(side="left", padx=6)

    def _channelid_for_pc_vm(self, bot_data: dict, pc_num: int, vm_num: int) -> str:
        """pcs[pc].vms[vm].channelid (신규). 구형 pcs[pc].channelid 는 VM1 전용으로만 호환."""
        pcs = bot_data.get("pcs") or {}
        entry = pcs.get(str(pc_num))
        if not entry:
            raise Exception(f"bot.json에 PC {pc_num} 정보가 없습니다.")

        vms = entry.get("vms")
        if isinstance(vms, dict):
            vm_entry = vms.get(str(vm_num))
            if not isinstance(vm_entry, dict):
                raise Exception(f"bot.json에 PC {pc_num} VM {vm_num} 항목이 없습니다.")
            return (vm_entry.get("channelid") or "").strip()

        if vm_num != 1:
            raise Exception(
                f"구형 bot.json은 PC{pc_num} VM1(channelid)만 있습니다. "
                "Google Drive bot.json을 새 형식(pcs → vms → 1~4)으로 바꾸세요."
            )
        return (entry.get("channelid") or "").strip()

    def update_setting_ini_from_bot_json(self, pc_num: int, vm_num: int):
        """bot.json(token, integratedchannelid, pcs[pc].vms[vm].channelid) + Pc, Vm → settings.ini."""
        with open(self.bot_json_path, "r", encoding="utf-8") as f:
            bot_data = json.load(f)

        channelid = self._channelid_for_pc_vm(bot_data, pc_num, vm_num)
        if not channelid:
            raise Exception(
                f"PC {pc_num} VM {vm_num}의 channelid가 비어 있습니다. bot.json·드라이브 파일을 채워 주세요."
            )

        token = (bot_data.get("token") or "").strip()
        integrated = (bot_data.get("integratedchannelid") or "").strip()
        if not token or not integrated:
            raise Exception("bot.json의 token 또는 integratedchannelid가 비어 있습니다.")

        # money.pyw save_settings 와 동일한 키 이름 (대소문자)
        update_values = {
            "Token": token,
            "ChannelID": channelid,
            "IntegratedChannelID": integrated,
            "Pc": str(pc_num),
            "Vm": str(vm_num),
        }
        key_alias = {
            "token": "Token",
            "channelid": "ChannelID",
            "integratedchannelid": "IntegratedChannelID",
            "pc": "Pc",
            "vm": "Vm",
        }

        if os.path.exists(self.setting_ini_path):
            with open(self.setting_ini_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            updated_keys = set()
            new_lines = []
            in_default = False

            for line in lines:
                stripped = line.strip()
                if stripped == "[DEFAULT]":
                    in_default = True
                    new_lines.append("[DEFAULT]\n")
                    continue
                if stripped.startswith("[") and stripped.endswith("]"):
                    in_default = False
                    new_lines.append(line)
                    continue

                if in_default and "=" in stripped and stripped:
                    raw_key = stripped.split("=", 1)[0].strip()
                    lk = raw_key.lower().replace(" ", "")
                    canon = key_alias.get(lk, raw_key)
                    if canon in update_values:
                        new_lines.append(f"{canon} = {update_values[canon]}\n")
                        updated_keys.add(canon)
                        continue
                    new_lines.append(line)
                    continue

                if not in_default:
                    new_lines.append(line)
                elif stripped:
                    new_lines.append(line)

            for key, value in update_values.items():
                if key not in updated_keys:
                    ins = len(new_lines)
                    for i in range(len(new_lines) - 1, -1, -1):
                        if new_lines[i].strip() == "[DEFAULT]":
                            for j in range(i + 1, len(new_lines)):
                                if new_lines[j].strip():
                                    ins = j + 1
                                    break
                            break
                        if new_lines[i].strip().startswith("[") and new_lines[i].strip() != "[DEFAULT]":
                            ins = i
                            break
                    new_lines.insert(ins, f"{key} = {value}\n")

            with open(self.setting_ini_path, "w", encoding="utf-8") as f:
                for line in new_lines:
                    f.write(line)
        else:
            with open(self.setting_ini_path, "w", encoding="utf-8") as f:
                f.write("[DEFAULT]\n")
                for key, value in update_values.items():
                    f.write(f"{key} = {value}\n")
    
    def toggle_autostart(self):
        """자동 실행을 토글합니다."""
        try:
            autostart_enabled = self.autostart_var.get()
            
            config = {'start': autostart_enabled}
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            
            if autostart_enabled:
                self.setup_autostart()
                messagebox.showinfo("설정", "자동 실행이 활성화되었습니다.")
            else:
                self.remove_autostart()
                messagebox.showinfo("설정", "자동 실행이 비활성화되었습니다.")
                
        except Exception as e:
            messagebox.showerror("오류", f"자동 실행 설정 중 오류: {e}")
        
    def update_status(self, message):
        """상태 메시지를 업데이트합니다."""
        self.status_label.config(text=message)
        self.root.update()

    def _get_windows_desktop(self) -> str:
        """바탕화면 경로 (영문 Desktop / OneDrive Desktop)."""
        home = os.path.expanduser("~")
        for name in ("Desktop", os.path.join("OneDrive", "Desktop")):
            p = os.path.join(home, name)
            if os.path.isdir(p):
                return p
        return os.path.join(home, "Desktop")

    @staticmethod
    def _merge_tree_overwrite(src_dir: str, dst_dir: str) -> None:
        """기존 dst_dir 를 지우지 않고, src_dir 내용을 같은 경로로 덮어쓰기·병합."""
        os.makedirs(dst_dir, exist_ok=True)
        for name in os.listdir(src_dir):
            s = os.path.join(src_dir, name)
            d = os.path.join(dst_dir, name)
            if os.path.isdir(s):
                MoneyPatcher._merge_tree_overwrite(s, d)
            else:
                shutil.copy2(s, d)

    def download_images(self):
        """GitHub에서 macro.zip 다운로드(임시 파일) → 바탕화면\\macro 에 덮어쓰기·병합. zip 파일은 남기지 않음."""
        def download_thread():
            import zipfile

            zip_path = None
            try:
                self.image_btn.config(state='disabled')
                self.update_status("압축 파일 다운로드 중...")

                desktop = self._get_windows_desktop()
                macro_root = os.path.join(desktop, "macro")

                file_content = self.download_file_to_memory(self.macro_filename)
                with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tf:
                    zip_path = tf.name
                    tf.write(file_content.getvalue())

                self.update_status("바탕화면\\macro 로 압축 해제 중...")
                zip_password = b"dbstn0422"

                with tempfile.TemporaryDirectory() as tmp:
                    unzip_dir = os.path.join(tmp, "u")
                    os.makedirs(unzip_dir, exist_ok=True)
                    with zipfile.ZipFile(zip_path, "r") as zip_ref:
                        zip_ref.setpassword(zip_password)
                        zip_ref.extractall(unzip_dir)

                    top_names = os.listdir(unzip_dir)
                    top_paths = [os.path.join(unzip_dir, n) for n in top_names]

                    layout = os.path.join(tmp, "layout")
                    os.makedirs(layout, exist_ok=True)
                    if len(top_paths) == 1 and os.path.isdir(top_paths[0]):
                        inner = top_paths[0]
                        for name in os.listdir(inner):
                            shutil.move(
                                os.path.join(inner, name),
                                os.path.join(layout, name),
                            )
                    else:
                        for n in top_names:
                            shutil.move(
                                os.path.join(unzip_dir, n),
                                os.path.join(layout, n),
                            )

                    if os.path.isfile(macro_root):
                        os.remove(macro_root)
                    os.makedirs(macro_root, exist_ok=True)
                    self._merge_tree_overwrite(layout, macro_root)

                self.update_status("매크로 압축 해제 완료!")
                messagebox.showinfo(
                    "완료",
                    f"바탕화면\\macro 에 덮어쓰기·병합했습니다.\n\n{macro_root}",
                )

            except Exception as e:
                messagebox.showerror("오류", f"다운로드/압축 해제 오류: {str(e)}")
            finally:
                if zip_path:
                    try:
                        os.unlink(zip_path)
                    except OSError:
                        pass
                self.image_btn.config(state="normal")

        threading.Thread(target=download_thread, daemon=True).start()
    
    def run_macro_bat(self):
        """바탕화면\\macro 의 money.bat 또는 macro.bat 실행."""
        def macro_thread():
            try:
                self.macro_btn.config(state='disabled')
                self.update_status("매크로 실행 준비 중...")

                macro_dir = os.path.join(self._get_windows_desktop(), "macro")
                bat_path = None
                for name in ("money.bat", "macro.bat"):
                    p = os.path.join(macro_dir, name)
                    if os.path.isfile(p):
                        bat_path = p
                        break

                if bat_path:
                    self.update_status("매크로 실행 중...")
                    subprocess.Popen(
                        [bat_path],
                        cwd=macro_dir,
                        creationflags=subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NO_WINDOW,
                    )
                    self.update_status("매크로 실행 완료!")
                    messagebox.showinfo("완료", "매크로가 실행되었습니다.")
                else:
                    self.update_status("bat 없음 — 다운로드 먼저")
                    messagebox.showerror(
                        "오류",
                        f"바탕화면\\macro 에 money.bat / macro.bat 이 없습니다.\n"
                        f"다운로드 버튼으로 macro.zip 을 받은 뒤 다시 시도하세요.\n경로: {macro_dir}",
                    )

            except Exception as e:
                print(f"매크로 실행 중 오류: {e}")
                messagebox.showerror("오류", f"매크로 실행 중 오류 발생: {str(e)}")
            finally:
                self.macro_btn.config(state='normal')

        threading.Thread(target=macro_thread, daemon=True).start()
    
    def run(self):
        """GUI를 실행합니다."""
        self.root.mainloop()

if __name__ == "__main__":
    app = MoneyPatcher()
    app.run()
