import os
import sys
import discord
from discord.ext import commands
from PIL import ImageGrab
import asyncio
import datetime
import cv2
import numpy as np
from pynput.keyboard import Key, Controller
import pyautogui
from concurrent.futures import ThreadPoolExecutor
import configparser
import random
import gdown
import time
import ctypes
import pyperclip
import subprocess
import psutil
import holidays
import aiofiles
# configparser 객체 생성
config = configparser.ConfigParser()


# 임시 파일의 경로를 설정합니다.
pidfile = 'ghost.pid'


# 임시 파일이 이미 존재하는 경우 프로그램이 이미 실행 중이라고 판단하고 종료합니다.
if os.path.isfile(pidfile):
    print(f"{pidfile} already exists, exiting")
    sys.exit()

# 임시 파일을 생성합니다.
open(pidfile, 'w').write("1")


# settings.ini 파일이 존재하는지 확인 및 생성
if not os.path.isfile('settings.ini'):
    config['DEFAULT'] = {
        'Token': 'Your Bot Token',
        'ChannelID': 'Your Channel ID',
        'IntegratedChannelID': 'Your Intergrated Channel ID',
        'Channel': '4',
        'Web': 'mgame',  # 기본 웹 설정
    }
    with open('settings.ini', 'w') as configfile:
        config.write(configfile)

# settings.ini 파일을 읽습니다.
config.read('settings.ini')

# 필수값만 있을 때 기본값 보장
if 'Web' not in config['DEFAULT']:
    config['DEFAULT']['Web'] = 'mgame'
if 'Channel' not in config['DEFAULT']:
    config['DEFAULT']['Channel'] = '4'
    # 바로 저장해서 다음 실행부터는 항상 값이 있음
    with open('settings.ini', 'w') as configfile:
        config.write(configfile)

# 설정을 읽습니다.
token = config['DEFAULT']['Token']
channel_id = int(config['DEFAULT']['ChannelID'])
intergrated_channel_id = int(config['DEFAULT']['IntegratedChannelID'])

# 봇 설정
intents = discord.Intents.default()
intents.message_content = True  # 메시지 내용에 접근할 수 있도록 설정
bot = commands.Bot(command_prefix='!', intents=intents)  # 명령어 !설정

# 상태 전역변수: 첫 실행에만 ini에서 불러오고, 이후엔 명령어로만 변경됨
web = config['DEFAULT'].get('Web', 'mgame')
channel = int(config['DEFAULT'].get('Channel', 4))

def save_settings():
    config['DEFAULT']['Web'] = str(web)
    config['DEFAULT']['Channel'] = str(channel)
    config['DEFAULT']['Token'] = str(token)
    config['DEFAULT']['ChannelID'] = str(channel_id)
    config['DEFAULT']['IntegratedChannelID'] = str(intergrated_channel_id)
    with open('settings.ini', 'w', encoding='utf-8') as configfile:
        config.write(configfile)


try:
    keyboard_controller = Controller()
    tasks = []  # 진행 중인 작업을 저장하는 리스트
    executor = ThreadPoolExecutor(max_workers=5)

    # 메시지 전송 함수
    async def send_message(channel, message):
        await channel.send(message)

    # 상태를 제어하는 전역 변수
    macro = False

    # 프로그램 시작 시간
    start_time = datetime.datetime.now()
    
    async def error_message(image_name):
        channel = bot.get_channel(channel_id)
        await send_message(channel, f"{image_name}을 찾을 수 없음 예외에러 발생 @everyone @here")
            
    async def image_search(image_name, time=100, delay=0.1):
        image = f"{image_name}.png"
        opencv_image = cv2.imread(image)
        if opencv_image is None:
            raise ValueError(f"Image {image} could not be read.")
    
        attempt = 0
        while True:
            screen = np.array(ImageGrab.grab())
            screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)
            result = cv2.matchTemplate(screen, opencv_image, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            if max_val > 0.9:
                return True, max_loc, min_val, min_loc  # 이미지를 찾으면 True와 좌표 반환
            attempt += 1
            if time > 0 and attempt >= time:
                if time == 1:
                    return False, None
                await error_message(image_name)
                await cleangame()
                return None, None
            await asyncio.sleep(delay)
    
    async def image_click(image_name, time=100, delay=0.1):
        image = f"{image_name}.png"
        opencv_image = cv2.imread(image)
        if opencv_image is None:
            raise ValueError(f"Image {image} could not be read.")

        attempt = 0
        while True:
            screen = np.array(ImageGrab.grab())
            screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)
            result = cv2.matchTemplate(screen, opencv_image, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            if max_val > 0.9:
                h, w = opencv_image.shape[:2]
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                pyautogui.moveTo(center_x, center_y)
                pyautogui.doubleClick(center_x, center_y)
                await asyncio.sleep(0.1)
                pyautogui.doubleClick(center_x, center_y)
                return max_loc
            attempt += 1
            if time > 0 and attempt >= time:
                await error_message(image_name)
                await cleangame()
                return None
            await asyncio.sleep(delay)
    async def image_click1(image_name, time=100, delay=0.1):
        image = f"{image_name}.png"
        opencv_image = cv2.imread(image)
        if opencv_image is None:
            raise ValueError(f"Image {image} could not be read.")

        attempt = 0
        while True:
            screen = np.array(ImageGrab.grab())
            screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)
            result = cv2.matchTemplate(screen, opencv_image, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            if max_val > 0.9:
                h, w = opencv_image.shape[:2]
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                await asyncio.sleep(2)
                pyautogui.moveTo(center_x, center_y)
                pyautogui.mouseDown(center_x, center_y)
                await asyncio.sleep(0.1)
                pyautogui.mouseUp(center_x, center_y)
                return max_loc
            attempt += 1
            if time > 0 and attempt >= time:
                await error_message(image_name)
                await cleangame()
                return None
            await asyncio.sleep(delay)
    
    async def password():
        # 2pw 이미지를 먼저 찾음
        image_search_result = await image_search('2pw', time=10, delay=0.1)
        if image_search_result is None or not image_search_result[0]:
            await error_message('2pw')
            return None

        # 지정한 영역만 캡처 (좌상단 1040,500 ~ 우하단 1140,630)
        bbox = (1040, 500, 1140, 630)
        screen = np.array(ImageGrab.grab(bbox=bbox))
        screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)

        numbers = ['2', '5', '8', '9', '6', '0']

        for num in numbers:
            template = cv2.imread(f'{num}.png')
            if template is None:
                await error_message(f'{num}.png 파일을 찾을 수 없습니다.')
                await cleangame()
                return None
            result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            if max_val < 0.8:
                await error_message(f'{num} 버튼을 찾을 수 없습니다.')
                await cleangame()
                return None
            h, w = template.shape[:2]
            center = (max_loc[0] + w // 2, max_loc[1] + h // 2)
            # 절대좌표로 변환
            real_center = (center[0] + bbox[0], center[1] + bbox[1])
            pyautogui.click(real_center)
            await asyncio.sleep(0.1)

        # pw 버튼 클릭은 image_click1 함수로 처리
        await image_click1('pw')
        await asyncio.sleep(0.1)

    async def check_game():
        error_images = ["error", "135", "rerror"]
        # game.exe 프로세스가 실행 중인지 확인
        game_running = any(proc.name().lower() == "game.exe" for proc in psutil.process_iter())
        error_found = False
        for img in error_images:
            found, *_ = await image_search(img, 1)
            if found:
                error_found = True
                break
    
        # black.png 체크 추가
        black_found = False
        found, *_ = await image_search("black", 1)
        if found:
            await asyncio.sleep(60)  # 1분 대기
            found2, *_ = await image_search("black", 1)
            if found2:
                black_found = True
    
        if not game_running or error_found or black_found:
            error_message = "게임이 실행 중이 아니거나 오류 이미지가 발견되었거나 black.png가 1분 연속 발견되었습니다."
            return False  # 문제가 있으면 False 반환
        else:
            return True   # 문제가 없으면 True 반환
                
    async def cheat_on():
        keyboard_controller.press(Key.f2)
        await asyncio.sleep(0.1)
        keyboard_controller.release(Key.f2)
        await asyncio.sleep(0.1)
            
    async def gaming():
        global macro
        channel = bot.get_channel(channel_id)
        await cheat_on()  # <- await 추가
        try:
            while macro:
                try:
                    if not await check_game():
                        await send_message(channel, "게임 접속을 시도합니다.")
                        await cleangame()
                        await access()
                        await send_message(channel, "게임 접속이 완료되었습니다.")
                        await asyncio.sleep(10)
                    await asyncio.sleep(1)  # 1초 대기
                except Exception as e:
                    channel = bot.get_channel(channel_id)
                    await send_message(channel, f"gaming 내부 예외 발생: {e}")
                    await asyncio.sleep(5)  # 예외 발생 시 잠시 대기 후 재시도
        except asyncio.CancelledError:
            macro = False
            channel = bot.get_channel(channel_id)
            await send_message(channel, "매크로가 중단되었습니다. (취소됨)")
            return
        
    async def cheat():
        # wheelboss.py와 같은 폴더의 launcher.dll 실행
        dll_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "launcher.dll")
        if os.path.exists(dll_path):
            subprocess.Popen(['rundll32', dll_path + ',Silent'])
        else:
            print("launcher.dll이 현재 폴더에 없습니다.")
    
    async def cleangame():
            pyautogui.doubleClick(755, 17)
            pyautogui.click(1900, 20)
            subprocess.run(["taskkill", "/f", "/im", "game.exe"])
            await asyncio.sleep(3)
            await cheat()
            await asyncio.sleep(2)
            
    async def access():
        global channel, web
        if await image_click('cheatlogin', time=300, delay=0.2) is None:
            return
        await asyncio.sleep(2)
        # 이미지 서치 (CHEATlogincheck.png) 서칭되지않으면 contuinue
        if await image_search('CHEATlogincheck', time=100, delay=0.1) is None:
            return
        subprocess.Popen([r"C:\Program Files\Google\Chrome\Application\chrome.exe"])
        await asyncio.sleep(2)
        prefix = 'm' if web == 'mgame' else 'h'
        if await image_click(f'{prefix}login', time=300, delay=0.1) is None:
            return
        if await image_click1(f'{prefix}webstart', time=300, delay=0.1) is None:
            return
        if await image_click1('lancherstart', time=300, delay=0.1) is None:
            return
        await asyncio.sleep(10)
        pyautogui.click(1900, 20)
        if await image_click('neko', time=180, delay=1) is None:
            return
        #await password()
        if await image_search('cheaton', time=100, delay=0.1) is None:
            await error_message('cheaton')
            return
        await cheat_on()
        if await image_click(f'channel{channel}') is None:
            return
        await asyncio.sleep(1)
        if await image_click('start', time=100, delay=0.1) is None:
            return
        if await image_search('check', time=60, delay=1) is None:
            await cleangame()
            return
    
        pyautogui.mouseDown(67, 45)
        await asyncio.sleep(0.1)
        pyautogui.mouseUp(67, 45)
        await asyncio.sleep(1)
        pyautogui.click(960, 540)
        pyautogui.mouseDown(67, 45)
        await asyncio.sleep(0.1)
        pyautogui.mouseUp(67, 45)
        await asyncio.sleep(1)
        pyautogui.mouseDown(285, 145)
        await asyncio.sleep(0.1)
        pyautogui.mouseUp(285, 145)
        await asyncio.sleep(1)
        pyautogui.mouseDown(67, 45)
        await asyncio.sleep(0.1)
        pyautogui.mouseUp(67, 45)
        await asyncio.sleep(1)
        pyautogui.mouseDown(277, 195)
        await asyncio.sleep(0.1)
        pyautogui.mouseUp(277, 195)
        await asyncio.sleep(0.1)
        pyautogui.mouseDown(277, 195)
        await asyncio.sleep(0.1)
        pyautogui.mouseUp(277, 195)
        await asyncio.sleep(1)
        pyautogui.click(960, 540)

    async def check_time():
        now = datetime.datetime.now()
        kr_holidays = holidays.KR(years=now.year)
        # 평일(월~금)인지 확인
        if now.weekday() >= 5:
            return True
        # 공휴일(빨간날)인지 확인
        if now.date() in kr_holidays:
            return True
        # 시간 범위 확인 (08:50 ~ 17:50)
        if (now.hour > 8 or (now.hour == 8 and now.minute >= 50)) and (now.hour < 17 or (now.hour == 17 and now.minute <= 50)):
            return False
        return True

            
    async def fury():
        keyboard_controller.press('4')
        await asyncio.sleep(0.05)
        keyboard_controller.release('4')
        keyboard_controller.press(Key.up)
        await asyncio.sleep(0.05)
        keyboard_controller.release(Key.up)
        

            
    
            
    async def check_hard():
        url = 'https://drive.google.com/uc?id=1-RvrH2Fibu706p0kC4IWOPaSwRhtsxci'
        gdown.download(url, 'file.txt', quiet=True)

        # 볼륨 시리얼 번호 가져오기 (C 드라이브 기준)
        try:
            output = subprocess.check_output('vol C:', shell=True, text=True)
            serial = None
            for line in output.splitlines():
                if "일련 번호" in line or "Serial Number" in line:
                    serial = line.split()[-1].strip().lower()
                    break
        except Exception:
            serial = None

        if serial is None:
            ctypes.windll.user32.MessageBoxW(
                0,
                "볼륨 시리얼 번호를 가져올 수 없습니다.",
                "경고",
                1
            )
            os.remove('file.txt')
            os._exit(0)

        with open('file.txt', 'r', encoding='utf-8') as f:
            lines = [line.strip().lower() for line in f.readlines()]
            if serial in lines:
                time.sleep(1)
                f.close()
                os.remove('file.txt')
                return
            else:
                ctypes.windll.user32.MessageBoxW(
                    0,
                    "등록이 되지 않았습니다. 관리자에게 문의해주세요. 볼륨 시리얼 번호가 복사되었습니다.",
                    "경고",
                    1
                )
                pyperclip.copy(serial)
                f.close()
                time.sleep(1)
                os.remove('file.txt')
                os._exit(0)
        # 프로그램이 종료될 때 임시 파일을 삭제합니다.
    @bot.command(aliases=['w'])
    async def web_cmd(ctx, value: str = None):
        global web
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        channel_obj = bot.get_channel(channel_id)
        if value is None:
            await send_message(channel_obj, f"현재 web 값은 {web} 입니다.")
        else:
            if value.lower() == "m":
                web = "mgame"
                save_settings()
                await send_message(channel_obj, "web 값이 mgame(으)로 변경되었습니다.")
            elif value.lower() == "h":
                web = "hangame"
                save_settings()
                await send_message(channel_obj, "web 값이 hangame(으)로 변경되었습니다.")
            else:
                await send_message(channel_obj, "m(엠게임) 또는 h(한게임)만 입력 가능합니다.")

    @bot.command(aliases=['c'])
    async def channel_cmd(ctx, x: int = None):
        global channel
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        channel_obj = bot.get_channel(channel_id)
        if x is None:
            await send_message(channel_obj, f"현재 채널값은 {channel} 입니다.")
        else:
            if 1 <= x <= 8:
                channel = x
                save_settings()
                await send_message(channel_obj, f"채널값이 {x}으로 변경되었습니다.")
            else:
                await send_message(channel_obj, "채널값은 1~8 사이의 숫자만 입력 가능합니다.")    
 
    # 봇 이벤트
    @bot.event
    async def on_ready():
        print(f'로그인 성공: {bot.user.name}!')
        channel = bot.get_channel(channel_id)
        await channel.send("매크로 준비완료")

    @bot.command(aliases=['1'])
    async def start(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        channel = bot.get_channel(channel_id)
        global macro
        if not macro:
            macro = True
            # check_potion 함수를 asyncio 작업으로 시작
            tasks.append(asyncio.create_task(gaming()))
            await send_message(channel, "시작")
    @bot.command(aliases=['도움말'])
    async def help_cmd(ctx):
        help_text = (
            "**[명령어 목록]**\n"
            "`!start` (`1`) : 매크로 시작\n"
            "`!stop` (`2`) : 매크로 중단\n"
            "`!game` (`3`) : 게임 접속(자동 로그인 및 실행)\n"
            "`!exit` (`4`) : 프로그램 종료 및 설정 저장\n"
            "`!entery` (`9`) : 입장 좌표 토글(퀘스트 유/무)\n"
            "`!web [m/h]` (`w`) : 게임사(mgame/한게임) 설정 또는 확인\n"
            "`!channel [숫자]` (`c`) : 채널 번호(1~8) 설정 또는 확인\n"
            "`!l` (`5`) : 현재 화면 전송\n"
        )
        await ctx.send(help_text)
        
    @bot.command(aliases=['3'])
    async def game(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        channel = bot.get_channel(channel_id)
        await send_message(channel, "게임 접속을 시작합니다.")
        await access()
        await cheat_on()
        await send_message(channel, "게임 접속이 완료되었습니다.")


    @bot.command(aliases=['2'])
    async def stop(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        channel = bot.get_channel(channel_id)
        global macro
        if macro:
            macro = False
            # 진행 중인 모든 작업을 취소
            await cheat_on()
            for task in tasks:
                task.cancel()
            tasks.clear()  # 작업 리스트를 비움
            await send_message(channel, "중단")
            
    
    
    #레벨확인 명령어
    @bot.command(aliases=['6'])
    async def l(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        #493, 184, 530, 222 영역을 캡처하여 level.png로 저장한뒤 channel.id로 보내기 다보냇으면 level.png삭제
        screen = np.array(ImageGrab.grab(bbox=(0, 0, 1920, 1080)))
        screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)
        cv2.imwrite("level.png", screen)
        channel = bot.get_channel(channel_id)
        await channel.send(file=discord.File('level.png'))
        os.unlink("level.png")
    
            
    
    @bot.command(aliases=['4'])
    async def exit(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        await ctx.send("프로그램 종료")
        save_settings()
        try:
            os.unlink(pidfile)
        except FileNotFoundError:
            pass
        os._exit(0)
    #프로그램이 시작될떄 작동되는 것들
    async def main():
        await bot.start(token)

    if __name__ == "__main__":
        asyncio.run(main())
# finally 블록도 동일하게 str()로 변환
finally:
    save_settings()
    try:
        os.unlink(pidfile)
    except FileNotFoundError:
        pass
