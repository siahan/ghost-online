import io
import tempfile
import os
from mega import Mega

def download_mega_file_memory_efficient(email, password, file_link, chunk_size=1024*1024):
    """
    메모리 효율적인 MEGA 파일 다운로드 (청크 단위 처리)
    
    Args:
        email (str): MEGA 계정 이메일
        password (str): MEGA 계정 비밀번호
        file_link (str): MEGA 파일 공유 링크
        chunk_size (int): 청크 크기 (기본값: 1MB)
    
    Yields:
        bytes: 파일 데이터 청크
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 로그인
        m = mega.login(email, password)
        
        # 파일 정보 가져오기
        file_info = m.get_link_info(file_link)
        file_name = file_info['name']
        file_size = file_info['size']
        
        print(f"다운로드 시작: {file_name} ({file_size} bytes)")
        
        # 임시 파일로 다운로드 후 청크 단위로 읽기
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_path = temp_file.name
        
        try:
            # 파일 다운로드
            m.download_url(file_link, dest_path=temp_path)
            
            # 청크 단위로 읽기
            with open(temp_path, 'rb') as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk
                    
        finally:
            # 임시 파일 삭제
            if os.path.exists(temp_path):
                os.unlink(temp_path)
                
    except Exception as e:
        print(f"다운로드 오류: {e}")
        yield None

def download_mega_file_with_progress(email, password, file_link, progress_callback=None):
    """
    진행률 표시가 있는 MEGA 파일 다운로드
    
    Args:
        email (str): MEGA 계정 이메일
        password (str): MEGA 계정 비밀번호
        file_link (str): MEGA 파일 공유 링크
        progress_callback (function): 진행률 콜백 함수 (percent: float)
    
    Returns:
        bytes: 파일 데이터
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 로그인
        m = mega.login(email, password)
        
        # 파일 정보 가져오기
        file_info = m.get_link_info(file_link)
        file_name = file_info['name']
        file_size = file_info['size']
        
        print(f"다운로드 시작: {file_name} ({file_size} bytes)")
        
        # 파일 다운로드
        file_data = m.download_url(file_link)
        
        # 진행률 100% 알림
        if progress_callback:
            progress_callback(100.0)
        
        print(f"다운로드 완료: {len(file_data)} bytes")
        
        return file_data
        
    except Exception as e:
        print(f"다운로드 오류: {e}")
        return None

# 사용 예시
if __name__ == "__main__":
    # 설정 정보
    MEGA_EMAIL = "your_email@example.com"
    MEGA_PASSWORD = "your_password"
    FILE_LINK = "https://mega.nz/file/..."
    
    # 방법 1: 메모리 효율적인 다운로드
    print("=== 메모리 효율적인 다운로드 ===")
    total_size = 0
    for chunk in download_mega_file_memory_efficient(MEGA_EMAIL, MEGA_PASSWORD, FILE_LINK):
        if chunk is None:
            break
        total_size += len(chunk)
        print(f"청크 다운로드: {len(chunk)} bytes (총 {total_size} bytes)")
    
    # 방법 2: 진행률 표시 다운로드
    print("\n=== 진행률 표시 다운로드 ===")
    def progress_callback(percent):
        print(f"진행률: {percent:.1f}%")
    
    file_data = download_mega_file_with_progress(
        MEGA_EMAIL, MEGA_PASSWORD, FILE_LINK, progress_callback
    )
    
    if file_data:
        print(f"최종 파일 크기: {len(file_data)} bytes") 