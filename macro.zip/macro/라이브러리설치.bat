@echo off
chcp 65001 >nul
cd /d "%~dp0"
title money / money_patcher - pip install

echo.
echo [1/2] pip upgrade
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 -m pip install --upgrade pip
) else (
  python -m pip install --upgrade pip
)
if %errorlevel% neq 0 (
  echo pip upgrade failed. Check Python is installed and PATH.
  pause
  exit /b 1
)

echo.
echo [2/2] discord.py, Pillow, opencv-python, numpy, pynput, pyautogui, psutil, pyperclip, requests
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 -m pip install discord.py Pillow opencv-python numpy pynput pyautogui psutil pyperclip requests
) else (
  python -m pip install discord.py Pillow opencv-python numpy pynput pyautogui psutil pyperclip requests
)
if %errorlevel% neq 0 (
  echo Package install failed.
  pause
  exit /b 1
)

echo.
echo Done.
pause
