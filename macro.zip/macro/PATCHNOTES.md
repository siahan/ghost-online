# 패치노트

이전 버전 생략. 새 버전 나올 때마다 **위쪽에** `## vX.Y.Z` 한 줄 추가.

---

## v1.4.6

- `!id apple`: **apple** 클릭 → **apple1** 인식 후 중심 **(-100,+130)** 클릭 → **!pw** 비밀번호 입력(web별 `pw_pos`) → **apple2**·**apple3** 클릭. 이미지: `apple.png`, `apple1.png`, `apple2.png`, `apple3.png`.

## v1.4.5

- `!web h`(한게임)일 때 **`clear_chrome_history_and_cache_preserving_startup` 호출 안 함** — `cleangame()`·`access()` 크롬 종료 후 기록 삭제 생략.

## v1.4.4

- exp `exp_mode_loop`: 위글·대기 **반복 30회**, 회마다 대기 **13.5초** (기존 16회·27초).
- exp: **snack1.png·snack2.png 둘 다 없으면** `snack("on")`/`("off")` 호출 안 함·**위글만** (있으면 기존처럼 스낵 후 위글).
- exp 포커스: v1.4.5 시도(위글마다 클릭) **취소** → 다시 `!1` 후 **정중앙 클릭 1회**만.

## v1.4.3

- exp: 스낵·위글 **병렬 태스크 제거** → 단일 **`exp_mode_loop`**. 순서: **snack on** → (←1초·→2초·27초 대기)×**16** → **snack off** 를 무한 반복. (`exp_parallel_lock`·`16×30` 스낵 주기 제거.)
- exp 위글: 오른쪽 키 홀드 **2초** 유지(왼쪽 1초).
- exp 포커스: `!1` 시작 시 **한 번만** Full HD 기준 화면 **정중앙(960,540) 클릭**. 사이클·위글 중 `game.exe` 창 포커스 호출 제거.

## v1.4.2

- exp: **snack(off→on)** 주기 복구. 스낵 루프·위글 루프 **태스크 2개 병렬**, 입력만 `asyncio.Lock`으로 직렬. 스낵 간격 `16×30`초.

## v1.4.1

- exp: **snack(off)→(on) 주기 제거**. 시작 시 `snack(on)` **한 번만** 후 위글만 반복(ESC/off가 사냥·마을 꼬이던 케이스 방지).

## v1.4.0

- exp 위글: Windows에서 **Win32 확장 방향키**(keybd_event + EXTENDEDKEY)로 ←1초·→1초. pynput은 일부 게임에서 무시됨.

## v1.3.9

- exp snack(on): snack1·snack2 **못 찾으면 ok 이미지도 안 씀.**

## v1.3.8

- exp snack: `snack.png` 폴백 제거 — **snack1·snack2만** 사용.

## v1.3.7

- exp 위글: **예전처럼** 같은 코루틴에서 `asyncio.sleep`으로 **왼 1초·오른 1초**(executor sleep 조합 제거).
- 스낵 직후 게임 창 다시 포커스 + 0.5초 대기 후 위글.

## v1.3.6

- exp 위글: **왼쪽 1초 → 뗌 → 오른쪽 2초 → 뗌** (요청대로). `press`/`release`는 봇 쪽에서, **초 단위 대기만** executor `time.sleep`이라 실제 홀드 길이는 맞고 입력도 안 씹힘.

## v1.3.5

- exp 위글: 루프가 밀려도 키 홀드가 늘어나지 않도록, 누름~뗌 구간만 스레드에서 `time.sleep`(wall-clock) 처리.

## v1.3.4

- exp 위글: 방향키 **짧게 탭**(각 약 0.1초). 예전 1초/2초 홀드 제거.

## v1.3.3

- exp 위글: 스낵 직후 **바로** 위글하도록 순서 수정(기존엔 30초 먼저 대기). 위글 전 `game.exe` 창 포커스, 키 stuck 방지 `finally` 릴리스.

## v1.3.2

**모드**

- **cheat** — day/night ini → 옵션 반영, KST로 주간·야간 전환, 매크로에서 게임 체크·스킬 등.
- **normal** — normal.ini → 옵션 복사.
- **exp** — exp.ini → 옵션 복사, `!1` 때 snack(이미지)·위글 루프 같이 돎.

**그 외**

- `!d` — 매크로 켜진 동안만 디버그 알림 on/off.
- 접속 중 neko 실패 후 ban 이미지 나오면 전부 멈추고 디스코드 알림.
