import io
from mega import Mega

def download_mega_file_to_memory(email, password, file_link):
    """
    MEGA에서 파일을 메모리로 다운로드하는 함수
    
    Args:
        email (str): MEGA 계정 이메일
        password (str): MEGA 계정 비밀번호
        file_link (str): MEGA 파일 공유 링크
    
    Returns:
        bytes: 파일 데이터 (메모리에 저장)
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 로그인
        m = mega.login(email, password)
        
        # 파일 링크에서 파일 정보 가져오기
        file_info = m.get_link_info(file_link)
        file_name = file_info['name']
        file_size = file_info['size']
        
        print(f"다운로드 중: {file_name} ({file_size} bytes)")
        
        # 파일을 메모리로 다운로드
        file_data = m.download_url(file_link)
        
        print(f"다운로드 완료: {len(file_data)} bytes")
        
        return file_data
        
    except Exception as e:
        print(f"다운로드 오류: {e}")
        return None

def download_mega_file_by_name(email, password, file_name):
    """
    파일명으로 MEGA에서 파일을 메모리로 다운로드하는 함수
    
    Args:
        email (str): MEGA 계정 이메일
        password (str): MEGA 계정 비밀번호
        file_name (str): 다운로드할 파일명
    
    Returns:
        bytes: 파일 데이터 (메모리에 저장)
    """
    try:
        # MEGA 클라이언트 초기화
        mega = Mega()
        
        # 로그인
        m = mega.login(email, password)
        
        # 계정의 모든 파일 검색
        files = m.get_files()
        
        # 파일명으로 검색
        target_file = None
        for file_id, file_info in files.items():
            if file_info['name'] == file_name:
                target_file = file_info
                break
        
        if target_file is None:
            print(f"파일을 찾을 수 없습니다: {file_name}")
            return None
        
        # 파일을 메모리로 다운로드
        file_data = m.download(target_file)
        
        print(f"다운로드 완료: {target_file['name']} ({len(file_data)} bytes)")
        
        return file_data
        
    except Exception as e:
        print(f"다운로드 오류: {e}")
        return None

# 사용 예시
if __name__ == "__main__":
    # 설정 정보
    MEGA_EMAIL = "your_email@example.com"
    MEGA_PASSWORD = "your_password"
    FILE_LINK = "https://mega.nz/file/..."
    FILE_NAME = "example.txt"
    
    # 방법 1: 링크로 다운로드
    file_data = download_mega_file_to_memory(MEGA_EMAIL, MEGA_PASSWORD, FILE_LINK)
    
    if file_data:
        # 메모리에서 파일 처리
        with io.BytesIO(file_data) as f:
            content = f.read().decode('utf-8')
            print(f"파일 내용: {content}")
    
    # 방법 2: 파일명으로 다운로드
    file_data = download_mega_file_by_name(MEGA_EMAIL, MEGA_PASSWORD, FILE_NAME)
    
    if file_data:
        # 메모리에서 파일 처리
        with io.BytesIO(file_data) as f:
            content = f.read().decode('utf-8')
            print(f"파일 내용: {content}") 